//export const apiDomain = 'https://etnafesapi20212018.etnafes.shop' //local ana nejeeeeeh
export const apiDomain = 'http://localhost:8000' //en ligne
export const API_URL = JSON.stringify('https://etnafes.com/sendsms.php')