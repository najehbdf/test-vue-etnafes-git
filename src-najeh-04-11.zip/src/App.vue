<template class="white-content">
  <div id="app" style="overflow-x: hidden">
    <!-- Messenger Plugin de discussion Code -->

    <div v-if="this.$store.state.loggedIn == true">
      <!--   <logout></logout> -->
      <!--   <close></close> -->
    </div>
    <div class="content">
      <notifications></notifications>
      <router-view :key="$route.fullPath"></router-view>
    </div>

    <div id="fb-root"></div>

    <!-- Your Plugin de discussion code -->
    <div id="fb-customer-chat" class="fb-customerchat"></div>
  </div>
</template>

 <script>
var chatbox = document.getElementById("fb-customer-chat");
chatbox.setAttribute("page_id", "103470018064973");
chatbox.setAttribute("attribution", "biz_inbox");

window.fbAsyncInit = function () {
  FB.init({
    xfbml: true,
    version: "v12.0",
  });
};

(function (d, s, id) {
  var js,
    fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://connect.facebook.net/fr_FR/sdk/xfbml.customerchat.js";
  fjs.parentNode.insertBefore(js, fjs);
})(document, "script", "facebook-jssdk");
</script>
<script>
import logout from "@/pages/logout.vue";
import close from "@/pages/logout_close.vue";

import Vue from "vue";
import BootstrapVue from "bootstrap-vue";
Vue.use(BootstrapVue);
export default {
  components: {
    logout,
    close,
  },
  methods: {
    disableRTL() {
      if (!this.$rtl.isRTL) {
        this.$rtl.disableRTL();
      }
    },
    toggleNavOpen() {
      let root = document.getElementsByTagName("html")[0];
      root.classList.toggle("nav-open");
    },
  },
  mounted() {
    this.$watch("$route", this.disableRTL, { immediate: true });
    this.$watch("$sidebar.showSidebar", this.toggleNavOpen);
  },
};
</script>

<style lang="scss">
#app {
  // font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;

  color: #2c3e50;
}
#nav {
  padding: 30px;
  a {
    font-weight: bold;
    color: #2c3e50;
    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
<style src="bootstrap-vue/dist/bootstrap-vue.css"></style>
