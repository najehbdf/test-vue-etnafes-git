<template>
  <div>
    <div class="container-fluid">
      <div class="row">
        <scroll-fixed-header
          :fixed.sync="fixed"
          :threshold="56"
          :class="{ change_color: scrollPosition > 50 }"
        >
          <TopNavbarHome />
        </scroll-fixed-header>
      </div>
    </div>

    <div
      class="container-fluid view full-page-intro"
      style="
        background-image: url('images/foret-etnafes-voyage.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
        height: auto !important;
      "
    >
      <!-- rech -->
      <div class="row">
        <div class="col-md-6 offset-md-3">
          <div class="container-fluid" style="height: 65px">
            <form class="d-flex tester">
              <input
                aria-label="Search"
                v-on:keyup.space="redirect()"
                v-model="search"
                class="form-control me-2 recherche style_rech_home"
                type="search"
                placeholder="Effectuez une recherche sur Etnafes"
              />
              <router-link
                :to="{
                  name: 'ResultatsRechercheHome',
                  query: { search: search },
                }"
              >
                <button
                  type="button"
                  class="btn btn-warning style_btn_rech_home"
                >
                  <i
                    class="tim-icons icon-zoom-split"
                    style="font-size: 20px"
                  ></i>
                </button>
              </router-link>
            </form>
          </div>
        </div>
      </div>
      <!-- fin rech -->
      <div
        class="
          mask
          rgba-black-light
          d-flex
          justify-content-center
          align-items-center
          d-none d-lg-block
        "
      >
        <div class="container container_home">
          <div class="row">
            <div class="col-md-12">
              <div class="card style_card">
                <!--Card content-->
                <div class="card-body" style="padding: 0px">
                  <!-- Form -->
                  <form name method="post" class="styleFORM">
                    <div class="row">
                      <div class="col-sm-12 col-xs-3">
                        <div class="row">
                          <div class="col-md-2 offset-md-1">
                            <div class="form-group">
                              <div>
                                <span
                                  style="
                                    line-height: 45px;
                                    font-size: 12px;
                                    letter-spacing: 0.7px;
                                  "
                                >
                                  <b>Destination</b>
                                </span>
                              </div>

                              <v-select
                                class="topAllinput"
                                placeholder="Où allez-vous ?"
                                v-model="pack.ville_id"
                                :options="villes"
                                value="id"
                                label="nom"
                              ></v-select>
                            </div>
                          </div>

                          <div class="col-md-2">
                            <div class="form-group">
                              <span
                                style="
                                  line-height: 45px;
                                  font-size: 12px;
                                  letter-spacing: 0.7px;
                                "
                              >
                                <b>Date d'arrivée</b>
                              </span>
                              <VueDatePicker
                                class="topAllinput"
                                :minDate="new Date()"
                                v-model="pack.date_deb"
                                placeholder="Ajoutez une date"
                              />
                            </div>
                          </div>
                          <!-- copie -->
                          <div class="col-sm-2">
                            <div class="form-group">
                              <div>
                                <span class="style_TYPE">
                                  <!--  style="
                                    line-height: 45px;
                                    font-size: 12px;
                                    letter-spacing: 0.7px;
                                  "-->
                                  <b>Type</b>
                                </span>
                              </div>

                              <v-select
                                class="topAllinput widthTYPE"
                                :options="types"
                                v-model="pack.vip"
                                placeholder="Quel type ?"
                              ></v-select>
                            </div>
                          </div>
                          &nbsp; &nbsp; &nbsp;
                          <div class="col-mx-1">
                            <div class="form-group adult_enf_rech_home">
                              <span>
                                <b>Adultes</b>
                              </span>
                              <div class="form-group">
                                <input
                                  aria-label="label"
                                  class="personalise1"
                                  v-on:input="updateNbAdulte"
                                  type="number"
                                  min="1"
                                  name="nb_adulte"
                                  required
                                  v-model="nb_adulte"
                                />
                              </div>
                            </div>
                          </div>
                          &nbsp; &nbsp; &nbsp;
                          <div class="col-mx-1">
                            <div class="form-group adult_enf_rech_home">
                              <span>
                                <b>Enfants</b>
                              </span>
                              <div class="form-group">
                                <input
                                  aria-label="label"
                                  class="personalise1"
                                  v-on:input="updateNbEnfant"
                                  type="number"
                                  :min="agestab.length"
                                  name="nb_enfant"
                                  required
                                  v-model="nb_enfant"
                                />
                              </div>
                            </div>
                          </div>
                          &nbsp; &nbsp; &nbsp;
                          <div class="col-mx-1" v-if="seen && nb_enfant != 0">
                            <div class="form-group adult_enf_rech_home">
                              <span>
                                <!-- style="line-height: 45px" -->
                                <b>AGES</b>
                              </span>
                              <div
                                class="form-group"
                                v-for="(age, index) in Number(this.nb_enfant)"
                                :key="index"
                              >
                                <select
                                  class="form-controlAGE personalise22"
                                  v-model="agestab[index]"
                                  @change="addNewAge"
                                >
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                  <option value="5">5</option>
                                  <option value="6">6</option>
                                  <option value="7">7</option>
                                  <option value="8">8</option>
                                  <option value="9">9</option>
                                  <option value="10">10</option>
                                  <option value="11">11</option>
                                  <option value="12">12</option>
                                  <option value="13">13</option>
                                  <option value="14">14</option>
                                  <option value="15">15</option>
                                </select>
                                <img
                                  class="image_minus_home"
                                  src="/minus-etnafes.png"
                                  v-on:click="removeAge(index)"
                                />
                              </div>
                            </div>
                          </div>
                          &nbsp; &nbsp; &nbsp;
                          <div class="col-md-1">
                            <router-link
                              :to="{
                                name: 'ResultatsRecherche',
                                query: {
                                  ville_id: pack.ville_id.id,
                                  date_deb: pack.date_deb,
                                  vip: pack.vip.value,
                                  nb_adulte: nb_adulte,
                                  nb_enfant: nb_enfant,
                                  ages: agestab,
                                },
                              }"
                            >
                              <button
                                v-if="
                                  pack.ville_id != '' &&
                                  pack.date_deb != null &&
                                  pack.vip != '' &&
                                  nb_adulte >= 1 &&
                                  nb_enfant != '' &&
                                  agestab.length == nb_enfant
                                "
                                type="submit"
                                class="btn btn-warning button_rech_home"
                              >
                                Rechercher
                              </button>
                            </router-link>
                            <button
                              v-if="
                                (pack.ville_id == '' &&
                                  pack.date_deb == null &&
                                  pack.vip == '' &&
                                  nb_enfant != agestab.length) ||
                                nb_enfant != agestab.length ||
                                (pack.ville_id == '' &&
                                  pack.date_deb == null) ||
                                (pack.ville_id == '' && pack.vip == '') ||
                                (pack.date_deb == null && pack.vip == '') ||
                                pack.vip == '' ||
                                pack.date_deb == null ||
                                pack.ville_id == ''
                              "
                              disabled
                              type="submit"
                              class="btn btn-warning button_rech_home"
                            >
                              Rechercher
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <br />
          <br />
          <!-- rech 2 -->

          <!-- fin rech 2 -->
        </div>
      </div>
    </div>

    <div class="container container_pourqoit_etnafes">
      <center>
        <h2 style="color: #000">Pourquoi partir avec Etnafes</h2>
      </center>
      <div class="row">
        <div class="col-md-3">
          <img
            class="img_pour_qoit_atnafes"
            src="images/icons8-touriste-homme-801.png"
          />

          <p class="stytle_txt_pour_qoit_etnafes">
            Destinations alternatives à découvrir en Tunisie
          </p>
        </div>
        <div class="col-md-3">
          <img
            src="images/icons8-tour-de-potier-8011.png"
            class="img_pour_qoit_atnafes"
          />

          <p class="stytle_txt_pour_qoit_etnafes">
            Vivre une expérience avec les artisans
          </p>
        </div>
        <div class="col-md-3">
          <img
            src="images/icons8-fermier-femme-801.png"
            class="img_pour_qoit_atnafes"
          />

          <p class="stytle_txt_pour_qoit_etnafes">
            Participer à des événements chez les femmes rurales
          </p>
        </div>
        <div class="col-md-3">
          <img
            src="images/icons8-argent-801.png"
            class="img_pour_qoit_atnafes"
          />

          <p class="stytle_txt_pour_qoit_etnafes">
            Profiter d'un prix raisonnable et à la portée de tous
          </p>
        </div>
      </div>
    </div>

    <!-- div mobile -->
    <!-- fin responsive moez -->

    <div>
      <div class="container" style="padding-bottom: 20px">
        <center>
          <h3 style="line-height: 40px; color: #000; padding-top: 30px">
            NOS DÉPARTS INITIÉS OU CONFIRMÉS
            <hr style="border-top: 2px solid #ff931f; width: 10%" />
          </h3>
        </center>
        <div class="row">
          <div class="col-lg-4" v-for="p in packsdep" :key="p.id">
            <div class="card" style="margin-bottom: 30px; margin-top: 10px">
              <router-link
                :to="{
                  name: 'DetailsPackAvis',
                  params: { id: p.id, vid: p.ville_id },
                }"
                @click.native="scrollToTop"
              >
                <div class="card-img-wrap">
                  <img
                    class="card-img imaa"
                    :src="`${apiDomain}/myapp/public/uploads/files_packs/${p.image_couverture}`"
                    alt="Card image cap"
                  />

                  <div
                    class="top-left badge"
                    style="background-color: rgb(40, 179, 81)"
                  >
                    Départ confirmé
                  </div>
                  <h4
                    class="centered"
                    style="
                      margin-bottom: 0px !important;
                      border-top-right-radius: 15px;
                      color: #fff;
                      background-color: rgba(34, 42, 66, 0.8);
                    "
                  >
                    {{ p.titre }}
                  </h4>
                </div>
              </router-link>
              <div class="card-block">
                <div style="padding-top: 12px; padding-bottom: 12px">
                  <center>
                    <img src="/date-deb-etnafes.png" width="6%" />&nbsp;
                    <span style="color: #5e6d77"
                      >{{ p.date_deb }} à {{ p.date_fin }}</span
                    >
                    <br />
                  </center>
                </div>
                <hr style="margin-top: 0rem; margin-bottom: 0rem" />

                <!-- moez resppnsive -->

                <div class="row images_pack_home">
                  <div class="col-mx-2 offset-md-1">
                    <center>
                      <img
                        class="imgWidthHome"
                        v-b-tooltip.hover
                        title="Prix enfant < 4ans"
                        src="/bebe-etnafes1.png"
                      />
                    </center>
                  </div>
                  <div class="col-mx-2">
                    <center>
                      <img
                        v-b-tooltip.hover
                        title="Prix enfant de 4 à 15ans"
                        src="/enfant-etnafes1.png"
                        class="imgWidthHome"
                      />
                    </center>
                  </div>

                  <div class="col-mx-2">
                    <center>
                      <img
                        v-b-tooltip.hover
                        title="Prix adulte"
                        src="adult-etnafes1.png"
                        class="imgWidthHome"
                      />
                    </center>
                  </div>

                  <div class="col-mx-2">
                    <center>
                      <img
                        v-b-tooltip.hover
                        title="Nombres des personnes"
                        src="/nombre-reservation-etnafes1.png"
                        class="imgWidthHome"
                      />
                    </center>
                  </div>
                  <div class="col-mx-2">
                    <center>
                      <img
                        v-b-tooltip.hover
                        title="Niveau d'activités physique"
                        src="/extreme-etnafes1.png"
                        class="imgWidthHome"
                      />
                    </center>
                  </div>
                </div>
                <!-- 2 eme row  -->
                <div class="row images_pack_home">
                  <div class="col-mx-2 offset-md-1">
                    <b>
                      <center class="prixPA">{{ p.prix_enfant4 }}dt</center>
                    </b>
                  </div>
                  <div class="col-mx-2">
                    <b>
                      <center class="prixPA">{{ p.prix_enfant15 }}dt</center>
                    </b>
                  </div>

                  <div class="col-mx-2">
                    <center>
                      <b class="prixPA2">{{ p.prix_fix }}dt</b>
                    </center>
                  </div>

                  <div class="col-mx-2">
                    <center>
                      <b class="prixPA2">{{ p.nb_place_max }}</b>
                    </center>
                  </div>
                  <div class="col-mx-2">
                    <center>
                      <b class="prixPA2">{{ p.adrenaline }}</b>
                    </center>
                  </div>
                </div>

                <!-- fin moez responsive -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div>
      <div class="container" style="padding-bottom: 20px">
        <center>
          <h3 style="line-height: 40px; color: #000; padding-top: 30px">
            DÉCOUVREZ LA TUNISIE
            <hr style="border-top: 2px solid #ff931f; width: 10%" />
          </h3>
        </center>
        <div class="row">
          <div class="col-lg-4" v-for="ville in villescot" :key="ville.id">
            <router-link :to="{ name: 'PackVille', params: { id: ville.id } }">
              <div class="card" style="margin-bottom: 30px; margin-top: 10px">
                <div class="card-img-wrap">
                  <img
                    class="card-img imaa"
                    :src="`${apiDomain}/myapp/public/uploads/files_ville/${ville.image}`"
                    alt="Card image cap"
                  />
                </div>
                <div class="card-block">
                  <h4 class="card-title" style="color: #c37600">
                    {{ ville.nom }}
                  </h4>
                  <p class="card-text" style="font-size: 15px">
                    Some quick example text to build on the card title and make
                    up the bulk of the card's content.
                  </p>

                  <br />
                </div>
              </div>
            </router-link>
          </div>
        </div>
        <router-link :to="{ name: 'NosVilles' }">
          <button class="btn btn-warning style_voir_plus">Voir Plus</button>
        </router-link>
      </div>
    </div>

    <div>
      <div class="container" style="padding-bottom: 20px">
        <center>
          <h3 style="line-height: 40px; color: #000; padding-top: 7px">
            Rejoignez notre réseau Etnafes
            <hr style="border-top: 2px solid #ff931f; width: 10%" />
          </h3>
        </center>
        <div class="row">
          <div class="col-lg-4">
            <router-link
              :to="{ name: 'LoginProprietaire' }"
              @click.native="scrollToTop"
            >
              <div class="card" style="margin-bottom: 30px; margin-top: 10px">
                <div class="card-img-wrap">
                  <img
                    class="card-img"
                    src="/images/hebergeur-maison-hote-etnafes.jpg"
                    alt="Card image cap"
                  />

                  <div
                    class="top-left badge"
                    style="background-color: rgb(40, 179, 81)"
                  >
                    Hébergeur
                  </div>
                  <h4
                    class="centered"
                    style="
                      margin-bottom: 0px !important;
                      border-top-right-radius: 15px;
                      color: #fff;
                      background-color: rgba(34, 42, 66, 0.8);
                    "
                  >
                    Partagez votre logement sur Etnafes
                  </h4>
                </div>
              </div>
            </router-link>
          </div>

          <div class="col-lg-4">
            <router-link
              :to="{ name: 'LoginAgence' }"
              @click.native="scrollToTop"
            >
              <div class="card" style="margin-bottom: 30px; margin-top: 10px">
                <div class="card-img-wrap">
                  <img
                    class="card-img"
                    src="/images/agence-de-voyage-etnafes.jpg"
                    alt="Card image cap"
                  />

                  <div
                    class="top-left badge"
                    style="background-color: rgb(40, 179, 81)"
                  >
                    Prestataire de Services
                  </div>
                  <h4
                    class="centered"
                    style="
                      margin-bottom: 0px !important;
                      border-top-right-radius: 15px;
                      color: #fff;
                      background-color: rgba(34, 42, 66, 0.8);
                    "
                  >
                    Organiser un circuit
                  </h4>
                </div>
              </div>
            </router-link>
          </div>

          <div class="col-lg-4">
            <router-link
              :to="{ name: 'LoginGuide' }"
              @click.native="scrollToTop"
            >
              <div class="card" style="margin-bottom: 30px; margin-top: 10px">
                <div class="card-img-wrap">
                  <img
                    class="card-img"
                    src="/images/guides-touristique3-etnafes-voyage.jpg"
                    alt="Card image cap"
                  />

                  <div
                    class="top-left badge"
                    style="background-color: rgb(40, 179, 81)"
                  >
                    Guide touristique
                  </div>
                  <h4
                    class="centered"
                    style="
                      margin-bottom: 0px !important;
                      border-top-right-radius: 15px;
                      color: #fff;
                      background-color: rgba(34, 42, 66, 0.8);
                    "
                  >
                    Compagnez nos voyageurs
                  </h4>
                </div>
              </div>
            </router-link>
          </div>
        </div>
      </div>
    </div>

    <Footer></Footer>
  </div>
</template>
<style type="text/css">
.imaa {
  height: 250px;
}
</style>

  <script>
import Calendar from "v-calendar/lib/components/calendar.umd";
import DatePicker from "v-calendar/lib/components/date-picker.umd";
import { VueDatePicker } from "@mathieustan/vue-datepicker";
import "@mathieustan/vue-datepicker/dist/vue-datepicker.min.css";
import { mapState, mapMutations, mapGetters } from "vuex";
import { VueperSlides, VueperSlide } from "vueperslides";
import "vueperslides/dist/vueperslides.css";
import axios from "axios";
import TopNavbarHome from "./Layout/TopNavbarHome.vue";
import Footer from "./Layout/Footer.vue";
import { required, minLength, between } from "vuelidate/lib/validators";
import { apiDomain } from "../config";
import Vue from "vue";
import slide from "@wyhaya/vue-slide";

export default {
  components: {
    VueDatePicker,
    TopNavbarHome,
    VueperSlides,
    VueperSlide,
    Footer,
    Calendar,
    DatePicker,
    slide,
  },
  data() {
    return {
      agestab: this.$route.query.ages ? this.$route.query.ages : [],
      search: "",
      disabledDates: {
        to: new Date(Date.now() - 8640000),
      },
      scrollPosition: null,
      fixed: false,
      types: [
        {
          label: "vip",
          value: "1",
        },

        {
          label: "simple",
          value: "0",
        },
      ],
      ages: [],
      validations: {
        date_deb: {
          required,
        },
        age: {
          between: between(20, 30),
        },
      },
      apiDomain: "http://localhost:8000",
      seen: false,
      zones: [],
      zonest: [],
      packs: [],
      villescot: [],
      newpacks: [],
      nb_adulte: 1,
      nb_enfant: "0",

      packsvedette: [],
      packsdep: [],

      pack: {
        vip: "",
        id: "",
        nom: "",
        date_deb: null,
        au: "",
        type: "",
        ville_id: "",
        description: "",
      },
      villes: [],
      ville: {
        id: "",
        nom_ville: "",
      },
    };
  },

  created() {
    this.fetchVilles();
    this.fetchVillesCot();

    this.fetchPacks();
    this.fetchPacksVedette();
    this.fetchPacksDep();
  },

  computed: {
    agesForm() {
      const ages = this.ages;
      var result = [];
      if (ages.length != 0) {
        for (var i = 0; i < ages.length - 1; i++) {
          result.push(ages[i]);
        }
      }
      return result;
    },
    enfants: {
      get() {
        return this.$store.state.nb_enfant;
      },
      set(value) {
        this.$store.commit("updateNbEnfant", value);
      },
    },

    adultes: {
      get() {
        return this.$store.state.nb_adulte;
      },
      set(value) {
        this.$store.commit("updateNbAdulte", value);
      },
    },
  },

  mounted() {
    window.addEventListener("scroll", this.updateScroll);
  },
  methods: {
    scrollToTop() {
      window.scrollTo(0, 0);
    },
    redirect() {
      window.location.href = `/resultatsHome?search=${this.search}`;
    },

    trigger() {
      this.$refs.research.click();
    },
    removeAge: function (index) {
      Vue.delete(this.agestab, index);
      this.nb_enfant = this.nb_enfant - 1;
    },
    updateScroll() {
      this.scrollPosition = window.scrollY;
    },
    addNewAge: function () {
      this.ages.push(Vue.util.extend({}, this.age));
    },
    updateNbEnfant(e) {
      this.seen = true;
      this.$store.commit("updateNbEnfant", e.target.value);
    },

    updateNbAdulte(e) {
      this.$store.commit("updateNbAdulte", e.target.value);
    },
    fetchVilles() {
      axios
        .get(`${apiDomain}/api/allvillesTun`)
        .then(({ data }) => (this.villes = data.villes));
    },

    fetchVillesCot() {
      axios
        .get(`${apiDomain}/api/villes/cot`)
        .then(({ data }) => (this.villescot = data));
    },

    fetchPacks() {
      axios
        .get(`${apiDomain}/api/packs`)
        .then(({ data }) => (this.newpacks = data.newpacks));
    },

    fetchPacksVedette() {
      axios
        .get(`${apiDomain}/api/packs/reservation`)
        .then(({ data }) => (this.packsvedette = data.packs));
    },

    fetchPacksDep() {
      axios
        .get(`${apiDomain}/api/departs/packs`)
        .then(({ data }) => (this.packsdep = data.packsdep));
    },
  },
};
</script>