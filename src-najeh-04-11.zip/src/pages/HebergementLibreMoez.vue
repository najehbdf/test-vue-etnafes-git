<template>
  <div>
    <TopNavbarHome />

    <b-modal id="modal-zone" :title="zone.nom" :zone="zone">
      <!-- <h3 style="margin-left:20px;margin-top:30px;color:#333">{{zone.nom}}</h3> -->

      <b-carousel
        id="carousel-1"
        v-model="slide"
        :interval="4000"
        controls
        indicators
        background="#ababab"
        img-width="1024"
        img-height="480"
        style="text-shadow: 1px 1px 2px #333; margin-top: 30px"
        @sliding-start="onSlideStart"
        @sliding-end="onSlideEnd"
      >
        <b-carousel-slide
          id="carousel2"
          v-for="(image, k) in zone.image"
          v-bind:key="k"
          :img-src="`${apiDomain}/myapp/public/uploads/files_zones/${image.url_image}`"
        ></b-carousel-slide>
      </b-carousel>

      <p style="margin-top: 10px">{{ zone.description }}</p>
      <div class="container" v-if="loggedIn && user.role == 2">
        <h4 style="color: #000; margin-top: 25px">Donnez votre Avis</h4>
        <ValidationObserver>
          <form v-on:submit.prevent="addAvisZone()" class="mb-3">
            <rate :length="5" v-model="avisz.nbr_etoile"></rate>
            <br />
            <ValidationProvider
              name="commentaire"
              rules="required"
              v-slot="{ errors }"
            >
              <div class="form-group">
                <textarea
                  rows="4"
                  class="form-control personalise"
                  v-model="avisz.commentaire"
                  placeholder="Commentaire"
                />
                <span class="message">{{ errors[0] }}</span>

                <p v-if="validationErrors.commentaire">
                  <span class="alert-link"
                    >* {{ validationErrors.commentaire[0] }}</span
                  >
                </p>
              </div>
            </ValidationProvider>

            <div class="row">
              <div class="col-md-3">
                <button class="btn btn-outline-success mt-3" type="submit" fill>
                  Envoyer
                </button>
              </div>
            </div>
          </form>
        </ValidationObserver>
      </div>

      <div class="container" style="margin-top: 20px" v-if="nbcomz > 0">
        <h5 style="color: blue">{{ nbcomz }} commentaires</h5>
        <br />

        <div class="row">
          <div class="col-md-12" v-for="avisz in aviszone" :key="avisz.id">
            <div class="row">
              <div class="col-md-4">
                <img
                  :src="`http://localhost:8000/myapp/public/uploads/files_guide/1602251763-11598521261.png`"
                  alt="Profile Photo"
                  width="60%"
                />
              </div>

              <div class="col-md-8">
                {{ avisz.client.nom }} {{ avisz.client.prenom }}
                <rate :length="5" v-model="avisz.nbr_etoile"></rate>
                {{ avisz.created_at }}
                <div class="row">
                  <p
                    style="
                      color: #333;
                      padding: 20px;
                      text-align: justify;
                      text-justify: inter-word;
                    "
                  >
                    {{ avisz.commentaire }}
                  </p>
                </div>
              </div>
            </div>
            <hr />
          </div>
          <br />
        </div>
        <br />

        <br />

        <button
          v-if="nbcomz > 3"
          @click="fetchAllAvisZone(zone.id)"
          class="btn btn-outline-success mt-3 btnout"
          fill
        >
          Afficher tous les {{ nbcomz }} commentaires >>
          <pulse-loader
            v-if="loadz == true"
            :loading="loading"
            :color="color"
            :size="size"
          ></pulse-loader>
        </button>
      </div>
    </b-modal>

    <b-modal
      id="modal-hebergement"
      :title="hebergement.nom"
      :hebergement="hebergement"
    >
      <p style="margin-left: 20px">
        {{ hebergement.nbr_voyageurs }} voyageurs --
        {{ hebergement.nbr_place_dispo }} places disponibles --
        <span v-if="hebergement.chambre_individuel > 0"
          >{{ hebergement.chambre_individuel }} Chambre individuel--</span
        >
        <span v-if="hebergement.chambre_a_deux > 0"
          >{{ hebergement.chambre_a_deux }} Chambre à deux--</span
        >
        <span v-if="hebergement.chambre_a_trois > 0"
          >{{ hebergement.chambre_a_trois }} Chambre à trois</span
        >
      </p>
      <b-carousel
        id="carousel-1"
        v-model="slide"
        :interval="4000"
        controls
        indicators
        background="#ababab"
        img-width="1024"
        img-height="480"
        style="text-shadow: 1px 1px 2px #333; margin-top: 30px"
        @sliding-start="onSlideStart"
        @sliding-end="onSlideEnd"
      >
        <b-carousel-slide
          id="carousel2"
          v-for="(image, k) in hebergement.images_hebergement"
          v-bind:key="k"
          :img-src="`${apiDomain}/myapp/public/uploads/files_hebergement/${image.url_image}`"
        ></b-carousel-slide>
      </b-carousel>

      <div class="col-md-12">
        <h3 style="margin-top: 10px; color: #000">Equipements</h3>
        <div class="row">
          <div v-if="hebergement.wifi == 1" class="col-md-3">
            <img src="wifi-etnafes.png" /> Wi-Fi
            <br />
          </div>
          <div v-if="hebergement.television == 1" class="col-md-3">
            <img src="tv-etnafes.png" /> Télévision
            <br />
          </div>

          <div v-if="hebergement.chauffage == 1" class="col-md-3">
            <img src="heating-etnafes.png" /> Chauffage
            <br />
          </div>

          <div v-if="hebergement.cuisine == 1" class="col-md-3">
            <img src="kitchen-etnafes.png" /> Cuisine
            <br />
          </div>

          <div v-if="hebergement.lave_linge == 1" class="col-md-3">
            <img src="tumble-dry-etnafes.png" /> Lave-linge
            <br />
          </div>
          <div v-if="hebergement.climatisation == 1" class="col-md-3">
            <img src="air-conditioner-etnafes.png" /> Climatisation
            <br />
          </div>

          <div v-if="hebergement.eau_chaude == 1" class="col-md-3">
            <img src="water-heater-etnafes.png" /> Eau Chaude
            <br />
          </div>

          <div v-if="hebergement.salle_de_bain == 1" class="col-md-3">
            <img src="bath-etnafes.png" /> Salle de bain
            <br />
          </div>

          <div
            v-if="hebergement.espace_travail_ordinateur == 1"
            class="col-md-5"
          >
            <img src="computer-etnafes.png" />
            &nbsp;Espace de travail pour ordinateur
            <br />
          </div>

          <div v-if="hebergement.espace_enfant == 1" class="col-md-3">
            <img src="computer-etnafes.png" />
            &nbsp;Espace pour enfant
            <br />
          </div>
        </div>
      </div>

      <div class="container" v-if="loggedIn">
        <h4 style="color: #000">Donnez votre Avis</h4>
        <ValidationObserver>
          <form v-on:submit.prevent="addAvisHebergement()" class="mb-3">
            <!-- :showcount="true" -->
            <rate :length="5" v-model="avisheb.nbr_etoile"></rate>
            <br />
            <ValidationProvider
              name="commentaire"
              rules="required"
              v-slot="{ errors }"
            >
              <div class="form-group">
                <textarea
                  rows="4"
                  class="form-control personalise"
                  v-model="avisheb.commentaire"
                  placeholder="Commentaire"
                />
                <span class="message">{{ errors[0] }}</span>

                <p v-if="validationErrors.commentaire">
                  <span class="alert-link"
                    >* {{ validationErrors.commentaire[0] }}</span
                  >
                </p>
              </div>
            </ValidationProvider>

            <div class="row">
              <div class="col-md-3">
                <button class="btn btn-outline-success mt-3" type="submit" fill>
                  Envoyer
                </button>
              </div>
            </div>
          </form>
        </ValidationObserver>
      </div>

      <div class="container" v-if="nbcomheb > 0">
        <h5 style="color: blue">{{ nbcomheb }} commentaires</h5>
        <br />

        <div class="row">
          <div
            class="col-md-12"
            v-for="avisheb in avishebergement"
            :key="avisheb.id"
          >
            <div class="row">
              <div class="col-md-4">
                <img
                  :src="`http://localhost:8000/myapp/public/uploads/files_guide/1602251763-11598521261.png`"
                  alt="Profile Photo"
                  width="60%"
                />
              </div>

              <div class="col-md-8">
                {{ avisheb.client.nom }} {{ avisheb.client.prenom }}
                <rate :length="5" v-model="avisheb.nbr_etoile"></rate>
                {{ avisheb.created_at }}
                <div class="row">
                  <p
                    style="
                      color: #333;
                      padding: 20px;
                      text-align: justify;
                      text-justify: inter-word;
                    "
                  >
                    {{ avisheb.commentaire }}
                  </p>
                </div>
              </div>
            </div>
            <hr />
          </div>
          <br />
        </div>
        <br />

        <br />

        <button
          v-if="nbcomheb > 3"
          @click="fetchAllAvisHebergement(hebergement.id)"
          class="btn btn-outline-success mt-3 btnout"
          fill
        >
          Afficher tous les {{ nbcomheb }} commentaires >>
          <pulse-loader
            v-if="loadheb == true"
            :loading="loading"
            :color="color"
            :size="size"
          ></pulse-loader>
        </button>
      </div>
    </b-modal>

    <div class="container">
      <center style="margin-bottom: 60px; margin-top: 40px">
        <h1 style="color: #333; margin-top: 20px">Etnafes Libre</h1>
        <h3 style="color: #ff931f; letter-spacing: 2px">
          Veuillez choisir votre destination
        </h3>
      </center>

      <div class="row" style="margin-top: 30px; margin-bottom: 40px">
        <div class="col-sm-12 col-xs-3">
          <div class="row">
            <div class="col-md-1">
              <div>
                <label style="color: #000; font-size: 14px">Pays</label>
              </div>
            </div>

            <div class="col-md-5">
              <div class="form-group">
                <select
                  class="form-control"
                  id="SelectRegion"
                  required
                  v-model="pays_id"
                  @change="fetchVillesPays(pays_id)"
                >
                  <option value disabled selected>choisissez votre pays</option>
                  <option
                    v-for="pays in pays"
                    v-bind:key="pays.id"
                    v-bind:value="pays.id"
                  >
                    {{ pays.nom_fr_fr }}
                  </option>
                </select>
              </div>
            </div>

            <div class="col-md-1">
              <div>
                <label style="color: #000; font-size: 14px">Gouvernorat</label>
              </div>
            </div>

            <div class="col-md-5">
              <div class="form-group">
                <select
                  class="form-control"
                  id="SelectRegion"
                  @change="updateVilleid"
                >
                  <option value disabled selected>
                    choisissez votre destination
                  </option>
                  <option
                    v-for="ville in villespays"
                    v-bind:key="ville.id"
                    v-bind:value="ville.id"
                  >
                    {{ ville.nom }}
                  </option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-7">
          <center class="style_centerèheb_libre">
            <h1 class="style_h1èheb_lib">Logements : Tunisie</h1>
            Veuillez choisir un logement
          </center>
          <h3
            style="color: #333; margin-top: 20px; margin-bottom: 10px"
            v-if="nomville.length != 0"
          >
            >> {{ nomville }}
          </h3>
          <div
            class="card mb-3 cardheb"
            v-for="hebergement in hebergementsville.data"
            :key="hebergement.id"
          >
            <div class="row no-gutters">
              <div class="col-md-3">
                <b-carousel
                  v-model="slide"
                  :interval="4000"
                  controls
                  indicators
                  background="#ababab"
                  style="text-shadow: 1px 1px 2px #333; margin-top: 30px"
                  @sliding-start="onSlideStart"
                  @sliding-end="onSlideEnd"
                >
                  <div>
                    <div @click="fetchHebergement(hebergement.id)">
                      <b-carousel-slide
                        id="carousel1"
                        v-b-modal.modal-hebergement
                        v-for="(image, k) in hebergement.images_hebergement"
                        v-bind:key="k"
                        :img-src="`${apiDomain}/myapp/public/uploads/files_hebergement/${image.url_image}`"
                        link="#"
                      ></b-carousel-slide>
                    </div>
                    <!-- </router-link> -->
                  </div>
                </b-carousel>
              </div>
              <div class="col-md-7">
                <div class="card-body">
                  <p
                    class="card-title"
                    style="font-weight: bold; letter-spacing: 1px"
                  >
                    &nbsp;{{ hebergement.nom }}
                  </p>
                  <hr />
                  <p class="card-text">
                    {{ hebergement.description }}
                    <br />
                    <small
                      class="text-muted"
                      style="color: #717171; font-size: 13px; font-weight: 400"
                    >
                      {{ hebergement.nbr_voyageurs }} voyageurs
                      <span>.</span>
                      {{ hebergement.nbr_chambre_dispo }} chambre(s)
                    </small>
                  </p>
                  <hr />
                  <p class="card-text">
                    <small>
                      <span v-if="hebergement.salle_de_bain == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Salle de bain"
                          src="bath-etnafes.png"
                        />
                        &nbsp;
                      </span>

                      <span v-if="hebergement.lave_linge == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Lave linge"
                          src="tumble-dry-etnafes.png"
                        />&nbsp;
                      </span>

                      <span v-if="hebergement.chauffage == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Chauffage"
                          src="heating-etnafes.png"
                        />&nbsp;
                      </span>
                      <span v-if="hebergement.television == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Television"
                          src="tv-etnafes.png"
                        />&nbsp;
                      </span>

                      <span v-if="hebergement.climatisation == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Climatisation"
                          src="air-conditioner-etnafes.png"
                        />&nbsp;
                      </span>

                      <span v-if="hebergement.eau_chaude == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Eau chaude"
                          src="water-heater-etnafes.png"
                        />&nbsp;
                      </span>

                      <span v-if="hebergement.espace_travail_ordinateur == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Espace de travail"
                          src="computer-etnafes.png"
                        />&nbsp;
                      </span>

                      <span v-if="hebergement.espace_enfant == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Espace enfant"
                          src="espace-enfant-etnafes.png"
                        />&nbsp;
                      </span>

                      <span v-if="hebergement.wifi == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="WiFi"
                          src="wifi-etnafes.png"
                        />&nbsp;
                      </span>

                      <span v-if="hebergement.cuisine == 1">
                        &nbsp;
                        <img
                          v-b-tooltip.hover
                          title="Cuisine"
                          src="kitchen-etnafes.png"
                        />&nbsp;
                      </span>
                    </small>
                  </p>
                </div>
              </div>
              <div class="col-md-2">
                <router-link :to="`/reservationhebergement/${hebergement.id}`">
                  <button type="button" class="btn btn-warning btn1">
                    + De détails
                  </button>
                </router-link>
              </div>
            </div>
          </div>

          <pagination
            :limit="4"
            :data="hebergementsville"
            @pagination-change-page="fetchHebergementsPaginate"
          ></pagination>
        </div>

        <div class="col-md-5">
          <center class="style_centerèheb_libre">
            <h1 class="style_h1èheb_lib">Zones Touristiques : Tunisie</h1>
            Voyagez et Découvrez de nouveaux endroits
          </center>
          <div class="row style_row_heb_libre">
            <div
              class="col-md-4 card"
              style="
                margin-bottom: 30px;
                margin-top: 10px;
                border: solid 1px #b6b6b6;
                padding: 10px;
              "
              v-for="zone in zonesville.data"
              :key="zone.id"
            >
              <b-carousel
                v-model="slide"
                :interval="4000"
                controls
                indicators
                background="#ababab"
                img-width="200"
                img-height="200"
                style="text-shadow: 1px 1px 2px #333; margin-top: 30px"
                @sliding-start="onSlideStart"
                @sliding-end="onSlideEnd"
              >
                <div @click="fetchZone(zone.id)">
                  <b-carousel-slide
                    id="carousel3"
                    v-for="(image, k) in zone.image"
                    v-b-modal.modal-zone
                    v-bind:key="k"
                    link="#"
                    :img-src="`${apiDomain}/myapp/public/uploads/files_zones/${image.url_image}`"
                  ></b-carousel-slide>
                </div>
              </b-carousel>
              {{ zone.nom }}
            </div>
          </div>
          <pagination
            :limit="4"
            :data="zonesville"
            @pagination-change-page="fetchZonesPaginate"
          ></pagination>

          <center
            style="margin-bottom: 30px"
            v-if="
              Object.keys(guidesville).length != 0 &&
              guidesville.data.length != 0
            "
          >
            <hr />
            <h1 style="color: #333; margin-top: 20px">Contactez un guide</h1>
          </center>
          <div class="row">
            <div
              class="col-md-4"
              v-for="(guide, i) in guidesville.data"
              :key="guide.id"
            >
              <center>
                <img
                  alt="guide"
                  :src="`${apiDomain}/myapp/public/uploads/files_guide/${guide.photo}`"
                  @mouseover="fetchAllAvisGuide(guide.id)"
                  width="50%"
                  :id="'tooltip-target-1' + i"
                />

                <b-tooltip :target="'tooltip-target-1' + i" triggers="hover">
                  <div class="toolsguide">
                    <b>{{ guide.nom }} {{ guide.prenom }}</b>
                    <br />
                    <b>Email:</b>
                    {{ guide.email }}
                    <br />
                    <b>Telephone:</b>
                    {{ guide.telephone }}
                    <br />
                    <div v-if="moyenne == 0">
                      <span style="color: #c37600">Pas d'avis encore</span>
                    </div>

                    <div v-if="moyenne == 1">
                      <img src="star-heb.png" />
                    </div>

                    <div v-if="moyenne == 2">
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                    </div>

                    <div v-if="moyenne == 3">
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                    </div>
                    <div v-if="moyenne == 4">
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                    </div>
                    <div v-if="moyenne == 5">
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                      <img src="star-heb.png" />
                    </div>
                    <br />
                  </div>
                </b-tooltip>

                <p style="color: #000; margin-top: 15px; margin-bottom: 15px">
                  {{ guide.nom }} {{ guide.prenom }}
                </p>
              </center>
            </div>
          </div>
          <pagination
            :limit="4"
            :data="guidesville"
            @pagination-change-page="fetchGuidesPaginate"
          ></pagination>

          <div class="row" v-if="markersh.length != 0 || markers.length != 0">
            <div class="col-md-12" id="map" ref="map">
              <br />

              <gmap-map
                :center="center"
                :zoom="8"
                style="width: 100%; height: 500px"
              >
                <GmapMarker
                  icon="/Etnafes-icon01.png"
                  v-for="(m, index) in markersh"
                  :key="index"
                  :position="m.position"
                  @click="toggleInfoWindow(m, index)"
                ></GmapMarker>
                <gmap-info-window
                  :options="infoOptions"
                  :position="infoWindowPos"
                  :opened="infoWinOpen"
                  @closeclick="infoWinOpen = false"
                >
                  <info-content :content="InfoDepanneur"></info-content>
                </gmap-info-window>
              </gmap-map>
            </div>
          </div>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>
<script>
import MapMarker from "../components/MapMarker";
import MapInfoWindow from "../components/MapInfoWindow";
import TopNavbarHome from "./Layout/TopNavbarHome.vue";
import Footer from "./Layout/Footer.vue";
import { VueperSlides, VueperSlide } from "vueperslides";
import "vueperslides/dist/vueperslides.css";
import BaseTable from "@/components/BaseTable";
import { Card } from "@/components/index";
import { apiDomain } from "../config";
import InfoDepanneur from "./InfoDepanneur.vue";
import PulseLoader from "vue-spinner/src/PulseLoader.vue";
const tableColumns = ["Titre", "Date_deb", "Date_fin", "Prix_fix"];

export default {
  components: {
    Card,
    BaseTable,
    TopNavbarHome,
    Footer,
    VueperSlides,
    VueperSlide,
    "info-content": InfoDepanneur,
    MapMarker,
    MapInfoWindow,
    PulseLoader,
  },
  data() {
    return {
      client: [],
      guide: [],
      adagence: [],

      proprietaire: [],
      proprestau: [],
      scrollPosition: null,
      token: null,
      nomville: "",
      aviszone: {},
      avisheb: {},
      avishebergement: {},
      nbcomheb: "",
      moyenne: "",
      zoneid: "",
      loadz: false,
      loadheb: false,

      validationErrors: "",
      avisz: {},
      villespays: {},
      infoContent: "",
      hebergement: {},
      zone: {},
      nbcomz: "",

      infoWindowPos: {
        lat: 0,
        lng: 0,
      },
      infoWinOpen: false,
      currentMidx: null,
      infoOptions: {
        pixelOffset: {
          width: 0,
          height: -35,
        },
      },
      pays_id: "",
      pays: {},
      map: null,
      center: { lat: 36.81897, lng: 10.16579 },
      markers: [],
      InfoDepanneur: [],
      markersh: [],
      places: [],
      currentPlace: null,
      slide: 0,
      sliding: null,
      villes: [],
      apiDomain: "http://localhost:8000",
      table1: {
        title: "Simple Table",
        columns: [...tableColumns],
      },
      packs: {},
      hebergements: {},
      hebergementsville: {},
      zonesville: {},
      guidesville: {},
      guide: {},
    };
  },

  computed: {
    loggedIn() {
      return this.$store.getters.get_loggedIn;
    },

    user() {
      return this.$store.getters.get_user;
    },

    ville_id: {
      get() {
        return this.$store.state.ville_id;
      },
      set(value) {
        this.$store.commit("updateVilleid", value);
      },
    },
  },

  created() {
    if (this.loggedIn == true) {
      this.fetchclient(this.$store.state.user.id);
      this.fetchproprietaire(this.$store.state.user.id);
      this.fetchproprestau(this.$store.state.user.id);
      this.fetchguide(this.$store.state.user.id);
      this.fetchagenceadmin(this.$store.state.user.id);
    }
    this.fetchPays();

    Bus.$on("markers_fetched", (data) => {
      this.markersh = data.markersh;
      if (this.markersh.length > 0) {
        this.center = data.markersh[0].position;
      }
      console.log("event data", data);
    });

    Bus.$on("marker_result_clicked", (index) => {
      let targetMarker = this.markersh[index];
      this.center = targetMarker.position;
      this.toggleInfoWindow(targetMarker, index);
    });
  },
  methods: {
    fetchagenceadmin(id) {
      fetch(`${apiDomain}/api/agencead/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.adagence = res.adagence;
        })
        .catch((err) => console.log(err));
    },
    fetchguide(id) {
      fetch(`${apiDomain}/api/guide/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.guide = res.guide;
        })
        .catch((err) => console.log(err));
    },
    fetchproprestau(id) {
      fetch(`${apiDomain}/api/proprietaire_restau/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.proprestau = res.proprietaire;
        })
        .catch((err) => console.log(err));
    },
    fetchproprietaire(id) {
      fetch(`${apiDomain}/api/prop/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.proprietaire = res.proprietaire;
        })
        .catch((err) => console.log(err));
    },
    //show user by id
    fetchclient(id) {
      fetch(`${apiDomain}/api/client/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.client = res;
        })
        .catch((err) => console.log(err));
    },
    fetchAllAvisHebergement(id) {
      this.loadheb = true;
      axios
        .get(`${apiDomain}/api/avishebergement/all/${id}`)
        .then(
          ({ data }) => (
            (this.avishebergement = data.hebergement), (this.loadheb = false)
          )
        );
    },
    addAvisHebergement() {
      axios
        .post(`${apiDomain}/api/avis/hebergement`, {
          email: this.$store.state.user.email,
          commentaire: this.avisheb.commentaire,
          nbr_etoile: this.avisheb.nbr_etoile,
          hebergement_id: this.hebergementid,
          client_id: this.$store.state.user.id,
          headers: {
            "content-type": "application/json",
          },
        })
        .then((response) => {
          if (response.status == 200) {
            if (confirm("avis bien reçu")) {
              window.location.reload();
            }
          }
        })
        .catch((error) => {
          if (error.response && error.response.status == 400) {
            this.validationErrors = error.response.data;
          }
        });
    },
    fetchAllAvisZone(id) {
      this.loadz = true;
      axios
        .get(`${apiDomain}/api/aviszone/all/${id}`)
        .then(
          ({ data }) => ((this.aviszone = data.zone), (this.loadz = false))
        );
    },

    fetchAllAvisGuide(id) {
      axios
        .get(`${apiDomain}/api/avisguide/all/${id}`)
        .then(
          ({ data }) => (
            (this.avisguide = data.guide), (this.moyenne = data.moyenne)
          )
        );
    },

    addAvisZone() {
      axios
        .post(`${apiDomain}/api/avis/zone`, {
          email: this.$store.state.user.email,
          commentaire: this.avisz.commentaire,
          nbr_etoile: this.avisz.nbr_etoile,
          zone_touristique_id: this.zoneid,
          client_id: this.$store.state.user.id,
          headers: {
            "content-type": "application/json",
          },
        })
        .then((response) => {
          if (response.status == 200) {
            if (confirm("avis bien reçu")) {
              window.location.reload();
            }
          }
        })
        .catch((error) => {
          if (error.response && error.response.status == 400) {
            this.validationErrors = error.response.data;
          }
        });
    },

    fetchHebergement(id) {
      fetch(`${apiDomain}/api/hebergement/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.hebergement = res.hebergement;
          this.imagehebergements = res.hebergement.images_hebergement;
        })
        .catch((err) => console.log(err));

      axios
        .get(`${apiDomain}/api/avishebergement/${id}`)
        .then(
          ({ data }) => (
            (this.avishebergement = data.hebergement),
            (this.nbcomheb = data.nbcomheb)
          )
        );
    },

    fetchZone(id) {
      fetch(`${apiDomain}/api/zone/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.zone = res.zonetouristique;
          this.zoneid = res.zonetouristique.id;
          this.imagezones = res.zonetouristique.image;
        })
        .catch((err) => console.log(err));

      axios
        .get(`${apiDomain}/api/aviszone/${id}`)
        .then(
          ({ data }) => (
            (this.aviszone = data.zone), (this.nbcomz = data.nbcomz)
          )
        );
    },

    fetchGuide(id) {
      fetch(`${apiDomain}/api/guide/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.guide = res.guide;
        })
        .catch((err) => console.log(err));
    },

    fetchVillesPays(id) {
      axios
        .get(`${apiDomain}/api/pays/villes/${id}`)
        .then(({ data }) => (this.villespays = data.villes));
    },
    fetchPays() {
      axios.get(`${apiDomain}/api/pays`).then(({ data }) => (this.pays = data));
    },
    toggleInfoWindow(marker, idx) {
      this.infoWindowPos = marker.position;
      this.InfoDepanneur = marker.position;

      if (this.currentMidx == idx) {
        this.infoWinOpen = !this.infoWinOpen;
      } else {
        this.infoWinOpen = true;
        this.currentMidx = idx;
      }
    },
    hasHistory() {
      return window.history.length > 2;
    },
    updateHebergementid(e) {
      this.$store.commit("updateHebergementid", e.target.value);
    },
    onSlideStart(slide) {
      this.sliding = true;
    },
    onSlideEnd(slide) {
      this.sliding = false;
    },

    fetchLocations(idv) {
      axios
        .post(`${apiDomain}/api/findh/${idv}`, { center: this.center })
        .then((response) => {
          let data = response.data;
          Bus.$emit("markers_fetched", data);
        });
    },

    updateVilleid(e) {
      this.$store.commit("updateVilleid", e.target.value);

      axios
        .get(
          `${apiDomain}/api/hebergements/ville/${this.$store.state.ville_id}`
        )
        .then(({ data }) => (this.hebergementsville = data.hebergements));

      axios
        .get(`${apiDomain}/api/zones/${this.$store.state.ville_id}/villep`)
        .then(({ data }) => (this.zonesville = data.zones));
      axios
        .get(`${apiDomain}/api/ville/${this.$store.state.ville_id}`)
        .then(
          ({ data }) => (
            (this.ville = data.ville), (this.nomville = data.ville.nom)
          )
        );
      axios
        .get(`${apiDomain}/api/guides/villep/${this.$store.state.ville_id}`)
        .then(({ data }) => (this.guidesville = data.guides));

      axios
        .post(`${apiDomain}/api/findh/${this.$store.state.ville_id}`, {
          center: this.center,
        })

        .then((response) => {
          let data = response.data;
          Bus.$emit("markers_fetched", data);
        });
    },
    fetchHebergementsPaginate(page) {
      if (typeof page === "undefined") {
        page = 1;
      }
      let vm = this;
      fetch(
        `${apiDomain}/api/hebergements/ville/${this.$store.state.ville_id}?page=` +
          page
      )
        .then((res) => res.json())
        .then((data) => {
          this.hebergementsville = data.hebergements;
        })
        .catch((err) => console.log(err));
    },
    fetchZonesPaginate(page) {
      if (typeof page === "undefined") {
        page = 1;
      }
      let vm = this;
      fetch(
        `${apiDomain}/api/zones/${this.$store.state.ville_id}/villep?page=` +
          page
      )
        .then((res) => res.json())
        .then((data) => {
          this.zonesville = data.zones;
        })
        .catch((err) => console.log(err));
    },

    fetchGuidesPaginate(page) {
      if (typeof page === "undefined") {
        page = 1;
      }
      let vm = this;
      fetch(
        `${apiDomain}/api/guides/villep/${this.$store.state.ville_id}?page=` +
          page
      )
        .then((res) => res.json())
        .then((data) => {
          this.guidesville = data.guides;
        })
        .catch((err) => console.log(err));
    },

    fetchHebergementsVille(id) {
      axios
        .get(`${apiDomain}/api/hebergements/ville/${id}`)
        .then(({ data }) => (this.hebergementsville = data.hebergements));
    },

    fetchZonesVille(id) {
      axios
        .get(`${apiDomain}/api/zones/${id}/ville`)
        .then(({ data }) => (this.zonesville = data.zones));
    },

    fetchVille(id) {
      axios
        .get(`${apiDomain}/api/ville/${id}`)
        .then(
          ({ data }) => (
            (this.ville = data.ville), (this.nomville = data.ville.nom)
          )
        );
    },

    fetchVilles() {
      axios
        .get(`${apiDomain}/api/villes`)
        .then(({ data }) => (this.villes = data));
    },
  },
};
</script>

<style>
.toolsguide {
  padding: 10px !important;
  color: #333 !important;
  text-align: center;
  background-color: #eeeeee !important;
  border-radius: 0.25rem;
}
</style>
