<template>
  <div>
    <TopNavbarHome />

    <b-modal id="modal-inscription" title="Réservation">
      <form v-on:submit.prevent="addClient()" class="mb-3">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input
                aria-label="nom"
                type="text"
                class="form-control"
                placeholder="nom"
                v-model="client.nom"
              />
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-group">
              <input
                aria-label="prenom"
                type="text"
                class="form-control"
                placeholder="prénom"
                v-model="client.prenom"
              />
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input
                aria-label="telephone"
                type="tel"
                class="form-control"
                placeholder="telephone"
                v-model="client.email"
              />
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <select
                class="form-control"
                name="civilite"
                placeholder="civilité"
                v-model="client.civilité"
                required
              >
                <option value="mr" selected>Mr</option>
                <option value="mme">Mme</option>
                <option value="mlle">Mlle</option>
              </select>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <input
                aria-label="email"
                type="email"
                class="form-control"
                placeholder="email"
                v-model="client.email"
              />
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-12 col-xs-3">
            <div class="row">
              <div class="col-md-7">
                <div
                  v-for="paiement in paiements"
                  :key="paiement.id"
                  style="padding: 5px; margin-bottom: 20px"
                >
                  <input
                    aria-label="paiement"
                    type="radio"
                    v-bind:key="paiement.id"
                    v-model="paiement_id"
                    v-bind:value="paiement.id"
                    name="paiement_id"
                  />
                  {{ paiement.type }}
                </div>
              </div>
            </div>
          </div>
        </div>

        <button
          class="btn btn-success"
          type="submit"
          fill
          style="margin-left: 10px"
        >
          S'inscrire
        </button>
      </form>
    </b-modal>

    <div class="container" style="margin-bottom: 70px">
      <div class="row">
        <div class="col-md-8">
          <b-card no-body>
            <h2 style="margin-left: 20px; margin-top: 30px">
              {{ hebergement.nom }}
            </h2>

            <p style="margin-left: 20px">
              {{ hebergement.nbr_voyageurs }} voyageurs --
              {{ hebergement.nbr_place_dispo }} places disponibles --
              <span v-if="hebergement.chambre_individuel > 0"
                >{{ hebergement.chambre_individuel }} Chambre individuel--</span
              >
              <span v-if="hebergement.chambre_a_deux > 0"
                >{{ hebergement.chambre_a_deux }} Chambre à deux--</span
              >
              <span v-if="hebergement.chambre_a_trois > 0"
                >{{ hebergement.chambre_a_trois }} Chambre à trois</span
              >
            </p>
            <b-carousel
              id="carousel-1"
              v-model="slide"
              :interval="4000"
              controls
              indicators
              background="#ababab"
              img-width="1024"
              img-height="480"
              style="text-shadow: 1px 1px 2px #333; margin-top: 30px"
              @sliding-start="onSlideStart"
              @sliding-end="onSlideEnd"
            >
              <b-carousel-slide
                v-for="(image, k) in hebergement.images_hebergement"
                v-bind:key="k"
                :img-src="`${apiDomain}/myapp/public/uploads/files_hebergement/${image.url_image}`"
              ></b-carousel-slide>
            </b-carousel>

            <div class="col-md-12">
              <div class="row">
                <div class="col-md-6">
                  <br />
                  <h2 style="margin-left: 20px; margin-top: 30px">
                    Equipements
                  </h2>
                  <div v-if="hebergement.wifi == 1">
                    <img src="/wifi-etnafes.png" /> Wi-Fi
                    <br />
                    <br />
                  </div>
                  <div v-else>
                    <img src="/wifi-etnafes.png" />
                    <del>Wi-Fi</del>
                    <br />
                    <br />
                  </div>
                  <div v-if="hebergement.television == 1">
                    <img src="/tv-etnafes.png" /> Télévision
                    <br />
                    <br />
                  </div>
                  <div v-else>
                    <img src="/tv-etnafes.png" />
                    <del>&nbsp;Télévision</del>
                    <br />
                    <br />
                  </div>

                  <div v-if="hebergement.chauffage == 1">
                    <img src="/heating-etnafes.png" /> Chauffage
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/heating-etnafes.png" />
                    <del>&nbsp;Chauffage</del>
                    <br />
                    <br />
                  </div>
                  <div v-if="hebergement.cuisine == 1">
                    <img src="/kitchen-etnafes.png" /> Cuisine
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/kitchen-etnafes.png" />
                    <del>&nbsp;Cuisine</del>
                    <br />
                    <br />
                  </div>

                  <div v-if="hebergement.lave_linge == 1">
                    <img src="/tumble-dry-etnafes.png" /> Lave-linge
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/tumble-dry-etnafes.png" />
                    <del>&nbsp;Lave-linge</del>
                    <br />
                    <br />
                  </div>
                </div>
                <div class="col-md-6">
                  <br />
                  <h2 style="margin-top: 30px">&nbsp;</h2>
                  <div v-if="hebergement.climatisation == 1">
                    <img src="/air-conditioner-etnafes.png" /> Climatisation
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/air-conditioner-etnafes.png" />
                    <del>&nbsp;Climatisation</del>
                    <br />
                    <br />
                  </div>

                  <div v-if="hebergement.eau_chaude == 1">
                    <img src="/water-heater-etnafes.png" /> Eau Chaude
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/water-heater-etnafes.png" />
                    <del>Eau Chaude</del>
                    <br />
                    <br />
                  </div>

                  <div v-if="hebergement.salle_de_bain == 1">
                    <img src="/bath-etnafes.png" /> Salle de bain
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/bath-etnafes.png" />
                    <del>&nbsp;Salle de bain</del>
                    <br />
                    <br />
                  </div>

                  <div v-if="hebergement.espace_travail_ordinateur == 1">
                    <img src="/computer-etnafes.png" />
                    &nbsp;Espace de travail pour ordinateur
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/computer-etnafes.png" />
                    <del>&nbsp;Espace de travail pour ordinateur</del>
                    <br />
                    <br />
                  </div>

                  <div v-if="hebergement.espace_enfant == 1">
                    <img src="/espace-enfant-etnafes.png" />
                    &nbsp;Espace pour enfant
                    <br />
                    <br />
                  </div>

                  <div v-else>
                    <img src="/espace-enfant-etnafes.png" />
                    <del>&nbsp;Espace pour enfant</del>
                    <br />
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </b-card>
        </div>

        <div class="col-md-4" id="map" ref="map">
          <br />
          <gmap-map
            :center="center"
            :zoom="8"
            style="width: 100%; height: 720px"
          >
            <GmapMarker
              icon="/Etnafes-icon01.png"
              :position="markersh.position"
              @click="toggleInfoWindow(markersh)"
            ></GmapMarker>
            <gmap-info-window
              :options="infoOptions"
              :position="infoWindowPos"
              :opened="infoWinOpen"
              @closeclick="infoWinOpen = false"
            >
              <info-content :content="InfoDepanneur"></info-content>
            </gmap-info-window>
          </gmap-map>
        </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>

<script>
import MapMarker from "../components/MapMarker";
import MapInfoWindow from "../components/MapInfoWindow";
import axios from "axios";
import { VueperSlides, VueperSlide } from "vueperslides";
import "vueperslides/dist/vueperslides.css";
import TopNavbarHome from "./Layout/TopNavbarHome.vue";
import Footer from "./Layout/Footer.vue";
import { apiDomain } from "../config";
import InfoDepanneur from "./InfoDepanneur.vue";
export default {
  components: {
    TopNavbarHome,
    Footer,
    VueperSlides,
    VueperSlide,
    "info-content": InfoDepanneur,
    MapMarker,
    MapInfoWindow,
  },
  data() {
    return {
      paiement_id: "",
      isHidden: true,
      index: null,
      infoContent: "",
      infoWindowPos: {
        lat: 0,
        lng: 0,
      },
      du: "",
      au: "",
      nb_nuit: "",

      infoWinOpen: false,
      currentMidx: null,
      infoOptions: {
        pixelOffset: {
          width: 0,
          height: -35,
        },
      },
      map: null,
      center: { lat: 36.81897, lng: 10.16579 },
      markers: [],
      InfoDepanneur: [],
      markersh: [],

      places: [],
      currentPlace: null,

      nb_adulte: this.$route.query.nb_adulte,
      nb_enfant: this.$route.query.nb_enfant,
      apiDomain: "http://localhost:8000",
      packsvedette: [],
      hebergements: {},
      hebergement: {},
      client: {},
      paiements: {},
      pack: {
        id: "",
        nom: "",
        du: "",
        description: "",
        au: "",
        type: "",
        ville_id: "",
      },
      slide: 0,
      sliding: null,
    };
  },

  created() {
    this.fetchHebergement(this.$route.params.id);
    this.fetchPaiements();
    this.fetchLocations(this.$route.params.id);
    Bus.$on("markers_fetched", (data) => {
      this.markers = data.markers;
      if (this.markers.length > 0) {
        this.center = data.markers[0].position;
      }
      console.log("event data", data);
    });

    Bus.$on("marker_result_clicked", (index) => {
      let targetMarker = this.markers[index];
      this.center = targetMarker.position;
      this.toggleInfoWindow(targetMarker, index);
    });

    Bus.$on("markers_fetched", (data) => {
      this.markersh = data.markersh;
      this.center = data.markersh.position;
    });

    Bus.$on("marker_result_clicked", (index) => {
      let targetMarker = this.markersh;
      this.center = targetMarker.position;
      this.toggleInfoWindow(targetMarker, index);
    });
  },
  methods: {
    fetchPaiements() {
      axios
        .get(`${apiDomain}/api/paiements`)
        .then(({ data }) => (this.paiements = data));
    },
    hasHistory() {
      return window.history.length > 2;
    },
    toggleInfoWindow(marker, idx) {
      this.infoWindowPos = marker.position;
      this.InfoDepanneur = marker.position;

      if (this.currentMidx == idx) {
        this.infoWinOpen = !this.infoWinOpen;
      } else {
        this.infoWinOpen = true;
        this.currentMidx = idx;
      }
    },

    onSlideStart(slide) {
      this.sliding = true;
    },
    onSlideEnd(slide) {
      this.sliding = false;
    },
    fetchPacksVedette(ville_id) {
      axios
        .get(`${apiDomain}/api/packs/reservation/${ville_id}`)
        .then(({ data }) => (this.packsvedette = data.pack));
    },

    fetchLocations(id) {
      axios
        .post(`${apiDomain}/api/findheb/${id}`, { center: this.center })
        .then((response) => {
          let data = response.data;
          Bus.$emit("markers_fetched", data);
        });
    },

    fetchHebergement(id) {
      fetch(`${apiDomain}/api/hebergement/${id}`)
        .then((res) => res.json())
        .then((res) => {
          this.hebergement = res.hebergement;
          this.imagehebergements = res.hebergement.images_hebergement;
        })
        .catch((err) => console.log(err));
    },
    fetchPacks(id) {
      axios
        .get(`${apiDomain}/api/packs/${id}`)
        .then(({ data }) => (this.pack = data.packdetail));
    },
  },
};
</script>