<template>
  <div>
    <TopNavbarHome />
    <div class="container" style="margin-bottom:30px;margin-top:40px;border:solid 1px #afaeae">
      <!-- Form -->
      <form method="post">
        <div class="row" style="margin-top:40px;">
          <div class="col-sm-12 col-xs-3">
            <h4
              class="dark-grey-text"
              style="line-height:60px;font-family: 'Open Sans', sans-serif;"
            >
              <strong style="font-family: 'Indie Flower', cursive;color:#000">Entrez vos coordonnées</strong>
            </h4>
          </div>
        </div>
        <div class="row" style="margin-top:30px;">
          <div class="col-sm-12 col-xs-3">
            <div class="row">
              <div class="col-md-1">
                <div>
                  <label style="color:#000;font-size:14px">Civilité :</label>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <select class="form-control" name="civilite" v-model="civilité" required>
                    <option value="mr" selected>Mr</option>
                    <option value="mme">Mme</option>
                    <option value="mlle">Mlle</option>
                  </select>
                </div>

                <div class="alert alert-danger" v-if="validationErrors.civilité">
                  <span>{{ validationErrors.civilité[0] }}</span>
                </div>
              </div>

              <div class="col-md-1">
                <div>
                  <label style="color:#000;font-size:14px">Prénom :</label>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <input
                    aria-label="label"
                    required
                    type="text"
                    class="form-control"
                    v-model="prenom"
                  />
                </div>
                <div class="alert alert-danger" v-if="validationErrors.prenom">
                  <span>{{ validationErrors.prenom[0] }}</span>
                </div>
              </div>

              <div class="col-md-1">
                <div>
                  <label style="color:#000;font-size:14px">Nom :</label>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <input aria-label="label" required type="text" class="form-control" v-model="nom" />
                </div>
                <div class="alert alert-danger" v-if="validationErrors.nom">
                  <span>{{ validationErrors.nom[0] }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row" style="margin-top:30px">
          <div class="col-sm-12 col-xs-3">
            <div class="row">
              <div class="col-md-1">
                <div>
                  <label style="color:#000;font-size:14px">Email :</label>
                </div>
              </div>

              <div class="col-md-5">
                <div class="form-group">
                  <input
                    aria-label="label"
                    required
                    type="email"
                    class="form-control"
                    v-model="email"
                  />
                </div>

                <div class="alert alert-danger" v-if="validationErrors.email">
                  <span>{{ validationErrors.email[0] }}</span>
                </div>
              </div>

              <div class="col-md-1">
                <div>
                  <label style="color:#000;font-size:14px">Portable :</label>
                </div>
              </div>

              <div class="col-md-5">
                <div class="form-group">
                  <input
                    aria-label="label"
                    required
                    type="tel"
                    class="form-control"
                    v-model="telephone"
                  />
                </div>

                <div class="alert alert-danger" v-if="validationErrors.telephone">
                  <span>{{ validationErrors.telephone[0] }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row" style="margin-top:30px;margin-bottom:40px;">
          <div class="col-sm-12 col-xs-3">
            <div class="row">
              <div class="col-md-2">
                <div>
                  <label style="color:#000;font-size:14px">Pays :</label>
                </div>
              </div>

              <div class="col-md-5">
                <div class="form-group">
                  <select
                    class="form-control"
                    id="SelectRegion"
                    required
                    v-model="pays_id"
                    @change="fetchVillesPays(pays_id)"
                  >
                    <option value disabled selected>choisissez votre pays</option>
                    <option
                      v-for="pays in pays"
                      v-bind:key="pays.id"
                      v-bind:value="pays.id"
                    >{{pays.nom_fr_fr}}</option>
                  </select>
                </div>
                <div class="alert alert-danger" v-if="validationErrors.gouvernorat">
                  <span>{{ validationErrors.gouvernorat[0] }}</span>
                </div>
              </div>

              <div class="col-md-5">
                <div class="form-group">
                  <select class="form-control" id="SelectRegion" required v-model="gouvernorat">
                    <option value disabled selected>choisissez votre destination</option>
                    <option
                      v-for="ville in villespays"
                      v-bind:key="ville.id"
                      v-bind:value="ville.nom"
                    >{{ville.nom}}</option>
                  </select>
                </div>
                <div class="alert alert-danger" v-if="validationErrors.gouvernorat">
                  <span>{{ validationErrors.gouvernorat[0] }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="offset-md-8"></div>
          <div class="col-md-2"></div>
        </div>
      </form>
    </div>

    <div class="container" style="margin-bottom:30px;margin-top:40px;border:solid 1px #afaeae">
      <!-- Form -->
      <form name method="post">
        <div class="row" style="margin-top:40px;">
          <div class="col-sm-12 col-xs-3">
            <h4
              class="dark-grey-text"
              style="line-height:60px;font-family: 'Open Sans', sans-serif;"
            >
              <strong
                style="font-family: 'Indie Flower', cursive;color:#000"
              >Choisissez le moyen de paiement</strong>
            </h4>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 col-xs-3">
            <div class="row">
              <div class="col-md-4">
                <div
                  v-for="paiement in paiements"
                  :key="paiement.id"
                  style="padding:5px;margin-bottom:20px"
                >
                  <input
                    aria-label="label"
                    type="radio"
                    v-bind:key="paiement.id"
                    v-model="paiement_id"
                    v-bind:value="paiement.id"
                    name="paiement_id"
                  />
                  {{paiement.type}}
                </div>

                <div class="alert alert-danger" v-if="validationErrors.paiement_id">
                  <span>{{ validationErrors.paiement_id[0] }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
    <div class="container" style="margin-bottom:30px">
      <router-link :to="`/paiement/${pack.id}`">
        <b-button v-on:click="addClient">Continuez</b-button>
      </router-link>
    </div>

    <Footer></Footer>
  </div>
</template>

<script>
import axios from "axios";
import TopNavbarHome from "./Layout/TopNavbarHome.vue";
import Footer from "./Layout/Footer.vue";
import { apiDomain } from "../config";
export default {
  components: {
    TopNavbarHome,
    Footer
  },
  data() {
    return {
      validationErrors: "",
      nom: "",
      prenom: "",
      email: "",
      telephone: "",
      civilité: "",
      gouvernorat: "",
      paiement_id: "",
      agence_id: null,

      paiements: {},
      villespays: {},

      pays: {},
      pays_id: "",

      pack: {
        id: "",
        nom: "",
        du: "",
        description: "",
        au: "",
        type: "",
        ville_id: ""
      }
    };
  },
  created() {
    this.fetchPacks(this.$route.params.id);
    this.fetchPaiements();
    this.fetchPays();
  },
  methods: {
    fetchPaiements() {
      axios
        .get(`${apiDomain}/api/paiements`)
        .then(({ data }) => (this.paiements = data));
    },

    fetchPays() {
      axios.get(`${apiDomain}/api/pays`).then(({ data }) => (this.pays = data));
    },

    fetchPacks(id) {
      axios
        .get(`${apiDomain}/api/packs/${id}`)
        .then(({ data }) => (this.pack = data.packdetail));
    },

    fetchVillesPays(id) {
      axios
        .get(`${apiDomain}/api/pays/villes/${id}`)
        .then(({ data }) => (this.villespays = data.villes));
    },

    addClient() {
      axios
        .post(`${apiDomain}/api/storeClient`, {
          nom: this.nom,
          prenom: this.prenom,
          telephone: this.telephone,
          email: this.email,
          civilité: this.civilité,
          gouvernorat: this.gouvernorat,
          agence_id: null,
          paiement_id: this.paiement_id,
          headers: {
            "content-type": "application/json"
          }
        })
        .then(function(response) {
          if (response.status == 200) {
            alert("Voyageur Ajoutée");
          }
        })
        .catch(error => {
          if (error.response && error.response.status == 422) {
            this.validationErrors = error.response.data.errors;
          }
        });
    }
  }
};
</script>
