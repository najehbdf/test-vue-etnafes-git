<template>
  <div>
    <div>
      <b-navbar toggleable="lg" type="dark" variant="info" class="navhome">
        <div class="col-md-3">
          <a href="/">
            <img
              src="/images/LOGO-ETNAFES-blanc1.png"
              width="38%"
              :class="{change_size: scrollPosition > 50}"
            />
          </a>
        </div>

        <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

        <b-collapse id="nav-collapse" is-nav>
          <b-navbar-nav class="ml-auto">
            <b-nav-item href="/">Accueil</b-nav-item>

            <b-nav-item-dropdown right v-if="!loggedIn">
              <template v-slot:button-content>Proprietaire</template>

              <b-dropdown-item href="/login/proprietaire">Hébergement</b-dropdown-item>
              <b-dropdown-item href="/login/proprietaire_restaurant">Restaurant</b-dropdown-item>
            </b-nav-item-dropdown>
            <b-nav-item href="/login/guide" v-if="!loggedIn">Guide</b-nav-item>
            <b-nav-item href="/login/client" v-if="!loggedIn">Voyageur</b-nav-item>

            <b-nav-item href="/login/agence" v-if="!loggedIn">Agence de voyage</b-nav-item>

            <b-nav-item href="/hebergementlibre">Etnafes Libre</b-nav-item>
            <b-nav-item href="/packs" active>Nos PACKS</b-nav-item>
            <b-nav-item-dropdown text="Lang" right>
              <b-dropdown-item href="#">EN</b-dropdown-item>
              <b-dropdown-item href="#">ES</b-dropdown-item>
              <b-dropdown-item href="#">RU</b-dropdown-item>
              <b-dropdown-item href="#">FA</b-dropdown-item>
            </b-nav-item-dropdown>

            <b-nav-item-dropdown right v-if="loggedIn">
              <template v-slot:button-content>
                <em>{{user.nom}} {{user.prenom}}</em>&nbsp;
                <img
                  v-if="user.role==2"
                  :src="`https://etnafesapi20212018.etnafes.shop/myapp/public/uploads/files_client/${client.photo}`"
                  alt="Profile Photo"
                  class="photo"
                />

                <img
                  v-if="user.role==6"
                  :src="`https://etnafesapi20212018.etnafes.shop/myapp/public/uploads/files_prop/${proprietaire.image}`"
                  alt="Profile Photo"
                  class="photo"
                />

                <img
                  v-if="user.role==5"
                  :src="`https://etnafesapi20212018.etnafes.shop/myapp/public/uploads/files_prop_restau/${proprestau.image}`"
                  alt="Profile Photo"
                  class="photo"
                />

                <img
                  v-if="user.role==4"
                  :src="`https://etnafesapi20212018.etnafes.shop/myapp/public/uploads/files_guide/${guide.photo}`"
                  alt="Profile Photo"
                  class="photo"
                />

                <img
                  v-if="user.role==3"
                  :src="`https://etnafesapi20212018.etnafes.shop/myapp/public/uploads/files_agence/${adagence.photo}`"
                  alt="Profile Photo"
                  class="photo"
                />
              </template>

              <!-- admin -->
              <b-dropdown-item v-if="user.role==1" href="/dashboard_admin">Profile</b-dropdown-item>

              <!-- client -->
              <b-dropdown-item v-if="user.role==2" href="/dashboard_client">Dashboard</b-dropdown-item>
              <b-dropdown-item v-if="user.role==2" href="/client">Profile</b-dropdown-item>
              <b-dropdown-item v-if="user.role==2" href="/reservations-client">Mes réservations</b-dropdown-item>

              <!-- agence -->
              <b-dropdown-item v-if="user.role==3" href="/dashboard_agence">Dashboard</b-dropdown-item>
              <b-dropdown-item v-if="user.role==3" href="/agence">Profile</b-dropdown-item>
              <b-dropdown-item v-if="user.role==3" href="/packs/agence">Mes packs</b-dropdown-item>
              <b-dropdown-item v-if="user.role==3" href="/agence-réservations">Mes réservations</b-dropdown-item>
              <b-dropdown-item v-if="user.role==3" href="/agences">Mes agences</b-dropdown-item>

              <!-- guide -->
              <b-dropdown-item v-if="user.role==4" href="/dashboard_guide">Dashboard</b-dropdown-item>
              <b-dropdown-item v-if="user.role==4" href="/guide">Profile</b-dropdown-item>

              <!-- proprietaire restaurant -->
              <b-dropdown-item v-if="user.role==5" href="/dashboard_proprietaire_restau">Dashboard</b-dropdown-item>
              <b-dropdown-item v-if="user.role==5" href="/proprietaire/restaurant">Profile</b-dropdown-item>
              <b-dropdown-item v-if="user.role==5" href="/allrestaurants">Mes restaurants</b-dropdown-item>

              <!-- proprietaire logement -->
              <b-dropdown-item v-if="user.role==6" href="/dashboard_proprietaire">Dashboard</b-dropdown-item>
              <b-dropdown-item v-if="user.role==6" href="/proprietaire">Profile</b-dropdown-item>
              <b-dropdown-item v-if="user.role==6" href="/allhebergements">Hebergements</b-dropdown-item>
              <b-dropdown-item v-if="user.role==6" href="/reservations-hebergement">Mes réservations</b-dropdown-item>

              <b-dropdown-item @click.prevent="performLogout">Déconnexion</b-dropdown-item>
            </b-nav-item-dropdown>
          </b-navbar-nav>
        </b-collapse>
      </b-navbar>
    </div>
    <!-- <TopNavbarHome /> -->

    <div>
      <div class="container" style="padding-bottom:20px">
        <center>
          <h3 style="line-height:20px;color:#000;padding-top:30px;margin-bottom:30px;">
            Nos Packs
            <hr style="border-top: 2px solid #ff931f;width:10%" />
          </h3>
        </center>
        <div class="row">
          <div class="col-md-12">
            <form class="d-flex">
              <input
                aria-label="label"
                type="text"
                class="form-control"
                @keyup="fetchsearch"
                v-model="q"
                placeholder="Chercher un pack : exemple par date 2020-10-01"
              />
            </form>
          </div>
        </div>
        <br />

        <div class="row">
          <div class="col-lg-4" v-for="(pack,i) in packsWithSearch.data" :key="pack.id">
            <router-link :to="{name:'DetailsPackAvis',params:{id:pack.id}}">
              <div class="card" style="margin-bottom:30px;margin-top:10px;">
                <div class="card-img-wrap">
                  <img
                    class="card-img-top"
                    id="imagepack"
                    :src="`${apiDomain}/myapp/public/uploads/files_packs/${pack.image_couverture}`"
                    alt="Card image cap"
                  />
                </div>
                <div class="card-block" style="height:170px">
                  <h4 class="card-title" style="color:#c37600">{{pack.titre}}</h4>
                  <h4
                    class="card-title"
                    style="color:#c37600"
                    v-if="pack.date_deb<(new Date().toISOString().split('T')[0])"
                  >
                    <span class="badge badge-warning" style="background-color:#ff4012">Pack expiré</span>
                  </h4>

                  <h4
                    class="card-title"
                    style="color:#c37600"
                    v-if="pack.date_deb>(new Date().toISOString().split('T')[0]) && i<=1"
                  >
                    <span class="badge badge-success" style="background-color:#28b351">Nouveau pack</span>
                  </h4>

                  <div class="output" style="margin-top:5px">
                    <p style="padding:10px">
                      <HighlightWords
                        class="wrapper"
                        highlightClassName="highlight"
                        highlightTag="i"
                        :searchWords="keywords"
                        :autoEscape="true"
                        :textToHighlight="pack.description"
                      ></HighlightWords>
                    </p>
                  </div>
                  <br />
                </div>
              </div>
            </router-link>
          </div>
        </div>

        <pagination
          :limit="4"
          :data="packsWithSearch"
          @pagination-change-page="getResults"
          class="mt-5"
        ></pagination>
      </div>
    </div>

    <Footer></Footer>
  </div>
</template>

  <script>
import HighlightWords from "vue-highlight-words";
import StrongProps from "../components/StrongProps";
import StrongSlot from "../components/StrongSlot";
import axios from "axios";
import TopNavbarHome from "./Layout/TopNavbarHome.vue";
import Footer from "./Layout/Footer.vue";
import { required, minLength, between } from "vuelidate/lib/validators";
import { apiDomain } from "../config";
import Vue from "vue";

export default {
  components: {
    TopNavbarHome,
    Footer,
    HighlightWords
  },
  data() {
    return {
      q: "",
      client: [],
      guide: [],
      admin: [],

      adagence: [],

      proprietaire: [],
      proprestau: [],
      scrollPosition: null,
      token: null,
      pagination: {},
      strongProps: StrongProps,
      strongSlot: StrongSlot,
      search: "",
      apiDomain: "https://etnafesapi20212018.etnafes.shop",
      packs: [],
      packsWithSearch: {}
    };
  },

  created() {
    if (this.loggedIn == true) {
      //client
      if (this.user.role == 2) this.fetchclient(this.$store.state.user.id);
      //proprietaire hébergement
      if (this.user.role == 6)
        this.fetchproprietaire(this.$store.state.user.id);
      //proprietaire restaurant
      if (this.user.role == 5) this.fetchproprestau(this.$store.state.user.id);
      //agence admin
      if (this.user.role == 3) this.fetchagenceadmin(this.$store.state.user.id);
      //guide
      if (this.user.role == 4) this.fetchguide(this.$store.state.user.id);
      //admin
      if (this.user.role == 1) this.fetchadmin(this.$store.state.user.id);
    }
    this.fetchsearch();
  },

  computed: {
    loggedIn() {
      return this.$store.getters.get_loggedIn;
    },

    user() {
      return this.$store.getters.get_user;
    },
    keywords() {
      return this.search.split(" ");
    },
    filteredPacks: function() {
      if (Array.isArray(this.packs)) {
        return this.packs.filter(pack => {
          return (
            pack.titre.match(this.search) ||
            pack.date_deb.match(this.search) ||
            pack.date_fin.match(this.search) ||
            pack.description.match(this.search)
          );
        });
      }
    }
  },

  methods: {
    performLogout() {
      this.$store
        .dispatch("performLogoutAction")
        .then(res => {
          this.$router.push("/");
        })
        .catch(err => {
          console.log(err);
        });
    },
    fetchadmin(id) {
      fetch(`${apiDomain}/api/admin/${id}`)
        .then(res => res.json())
        .then(res => {
          this.admin = res;
        })
        .catch(err => console.log(err));
    },
    //show user by id
    fetchagenceadmin(id) {
      fetch(`${apiDomain}/api/agencead/${id}`)
        .then(res => res.json())
        .then(res => {
          this.adagence = res.adagence;
        })
        .catch(err => console.log(err));
    },
    fetchguide(id) {
      fetch(`${apiDomain}/api/guide/${id}`)
        .then(res => res.json())
        .then(res => {
          this.guide = res.guide;
        })
        .catch(err => console.log(err));
    },
    fetchproprestau(id) {
      fetch(`${apiDomain}/api/proprietaire_restau/${id}`)
        .then(res => res.json())
        .then(res => {
          this.proprestau = res.proprietaire;
        })
        .catch(err => console.log(err));
    },
    fetchproprietaire(id) {
      fetch(`${apiDomain}/api/prop/${id}`)
        .then(res => res.json())
        .then(res => {
          this.proprietaire = res.proprietaire;
        })
        .catch(err => console.log(err));
    },
    //show user by id
    fetchclient(id) {
      fetch(`${apiDomain}/api/client/${id}`)
        .then(res => res.json())
        .then(res => {
          this.client = res;
        })
        .catch(err => console.log(err));
    },

    fetchsearch() {
      if (this.q.length > 1) {
        axios
          .get(`${apiDomain}/api/allpacks/search/` + this.q)
          .then(response => (this.packsWithSearch = response.data))
          .catch(error => console.log(error));
      } else {
        axios
          .get(`${apiDomain}/api/allpacks/search`)
          .then(response => (this.packsWithSearch = response.data))
          .catch(error => console.log(error));
      }
    },
    getResults(page = 1) {
      axios
        .get(`${apiDomain}/api/allpacks/search?page=` + page)
        .then(response => {
          this.packsWithSearch = response.data;
        });
    }
  }
};
</script>