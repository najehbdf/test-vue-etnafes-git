export const apiDomain = 'https://etnafesapi20212018.etnafes.shop'
export const API_URL = JSON.stringify('http://localhost:8080/sendsms.php')