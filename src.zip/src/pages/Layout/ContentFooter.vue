<template>
  <footer class="footer">
    <div class="container-fluid">
      <ul class="nav">
        <li class="nav-item">
          <a href="javascript:void(0)" class="nav-link">Etnafes</a>
        </li>
        <li class="nav-item">
          <a href="javascript:void(0)" class="nav-link">About Us</a>
        </li>
        <li class="nav-item">
          <a href="javascript:void(0)" class="nav-link">Blog</a>
        </li>
      </ul>
      <div class="copyright">
        <span>&copy; {{ new Date().getFullYear() }} made with</span>
        <span> <i class="tim-icons icon-heart-2"></i> by </span>
        <span>Etnafes</span> &nbsp;
        <span>for a better web.</span>
      </div>
    </div>
  </footer>
</template>
<script>
</script>
<style>
</style>
